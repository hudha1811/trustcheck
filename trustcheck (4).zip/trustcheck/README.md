# TrustCheck — implementation (prototype)

## What's actually running here

- **Backend:** Node.js + Express. Serves a JSON API and the static frontend.
- **Frontend:** plain HTML/CSS/JS (no React, no build step) — matches the dark dashboard mock, but every number is now pulled from `/api/companies` instead of being hardcoded.
- **Database:** none yet. `data/companies.json` and `data/reports.json` are flat files, read/written only through `src/store.js`. That indirection is intentional: swapping in a real database later means rewriting `store.js` only, nothing else.
- **Entity resolution:** `src/entityResolution.js` — Levenshtein-based fuzzy name matching + domain match + address similarity, weighted into a 0–1 score with three verdicts: `match`, `review`, `no_match`. Nothing auto-merges; `review` is exactly the ambiguous band you queue for a human.
- **Scoring engine:** `src/scoring.js` — implements the tier rubric exactly as specified (Tier 0–3, independence via deduped submitter hash, "separate time windows" check, strong-evidence shortcut to Tier 3).

## Answering "are we using any [X]"

- **Database:** no — JSON files for now. Good enough for a prototype/demo; swap for SQLite (easiest, zero-config) or Postgres before real users submit real reports.
- **Frontend framework:** no — vanilla JS. The mock said "React later, once wiring to a real DB" — that's still true, this is the "before" stage.
- **Auth:** no — the "verified college email" step just hashes the email client-submitted; there's no real domain verification (OTP to `.edu`/`.ac.in`) yet. Don't treat this as done — it's the piece flagged as needing real work before anything goes live.
- **Charting library:** no — the gauges are still the plain SVG stroke-dashoffset trick, no dependency.

## Running it

```
cd trustcheck
npm install
npm start
```

Then open `http://localhost:3000`.

## File map

```
trustcheck/
  server.js                 - Express entry point
  package.json
  data/
    companies.json          - seed companies (includes one alias pair: c001/c002)
    reports.json            - seed reports, tuned so each tier (1,2,3) shows up in the demo
  src/
    store.js                - all reads/writes go through here (swap point for a real DB)
    entityResolution.js      - fuzzy name/domain/address matching
    scoring.js               - tier rubric
  routes/
    companies.js            - GET /api/companies, /search, /:id, + dispute submit/approve/reject
    reports.js               - POST /api/reports, GET /queue, POST /:id/verify, /:id/reject
    evidence.js               - GET /api/evidence (flattened evidence across all companies, filterable)
    analysis.js                - GET /api/analysis (tier + evidence-type counts)
    settings.js                 - GET /api/settings (real scoring/matching thresholds, read-only)
  public/
    index.html               - dashboard (Home)
    company.html              - company record page (evidence log, reply, report + dispute forms)
    reports.html               - moderation queue: pending reports + pending company disputes
    evidence.html                - full evidence log, filterable by type / verified status
    analysis.html                 - tier distribution + evidence-type breakdown (CSS bar charts)
    settings.html                  - real thresholds display + a working "compact view" preference
    css/style.css
    js/ (one file per page above)
```

Every sidebar link and every gauge-card action ("View flagged", "Open queue", "See breakdown") now goes somewhere real. The two profile/bell icons in the top bar are still decorative — there's no auth or notification system behind them yet.

## Known gaps to close next (in rough priority order)

1. Real DB (SQLite is the least-friction upgrade from the JSON files).
2. Actual email-domain verification for the "independent verified student" hash, and for the dispute flow's `domainLooksLikeCompany` check — both are currently string comparisons, not real ownership proof.
3. Auth for the moderation queue (`/reports.html`) — right now anyone who finds the URL can verify/reject reports and approve/reject disputes. Fine for a prototype demo, not for anything real.
4. Settings page is read-only by design (the thresholds are constants in the code); an admin UI to actually edit and hot-reload them would need a config store, not hardcoded constants.
5. GSTIN/CIN lookup against MCA's public records, to make entity resolution's registry-match signal real instead of relying on seed data.
