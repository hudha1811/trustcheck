const express = require("express");
const router = express.Router();
const { MATCH_THRESHOLD, REVIEW_THRESHOLD } = require("../src/entityResolution");
const { TIME_WINDOW_DAYS } = require("../src/scoring");

// GET /api/settings -> the actual constants the scoring/matching code runs
// with. Read-only for now: changing these would need a restart, since
// they're hardcoded in src/entityResolution.js and src/scoring.js. Shown
// here so "Settings" reflects real config instead of being a static mock.
router.get("/", (req, res) => {
  res.json({
    entityResolution: {
      matchThreshold: MATCH_THRESHOLD,
      reviewThreshold: REVIEW_THRESHOLD,
    },
    scoring: {
      timeWindowDays: TIME_WINDOW_DAYS,
    },
  });
});

module.exports = router;
