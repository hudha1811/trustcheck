const express = require("express");
const router = express.Router();
const store = require("../src/store");
const { computeTier, computePlatformRiskIndex } = require("../src/scoring");
const { findCandidateMatches, rankCompaniesForSearch } = require("../src/entityResolution");

/** Attach alias names + computed tier to a raw company record. */
function enrichCompany(company, allCompanies) {
  const aliasNames = [...(company.aliasIds || []), ...(company.aliasOf || [])]
    .map((id) => allCompanies.find((c) => c.id === id)?.name)
    .filter(Boolean);

  const reports = store.getReportsForCompany(company.id);
  const tierResult = computeTier(reports);

  return {
    id: company.id,
    name: company.name,
    domain: company.domain,
    address: company.address,
    aliases: aliasNames,
    ...tierResult,
  };
}

// GET /api/companies/search?q=
router.get("/search", (req, res) => {
  const q = (req.query.q || "").trim();
  if (!q) return res.json({ results: [], exact: true });

  const companies = store.getCompanies();
  const exact = companies.filter((c) => c.name.toLowerCase().includes(q.toLowerCase()));

  const merged = new Map();
  for (const c of exact) merged.set(c.id, enrichCompany(c, companies));

  // Confidence-scored "did you mean" suggestions from entity resolution
  // (handles alias name drift - typing the old name of a relisted company).
  for (const cand of findCandidateMatches({ name: q }, companies, 5)) {
    if (!merged.has(cand.company.id)) {
      merged.set(cand.company.id, { ...enrichCompany(cand.company, companies), matchConfidence: cand.score });
    }
  }

  // Nothing close enough yet: don't dead-end on "no matches" - surface
  // the nearest companies in the database (lenient token-based ranking)
  // so the student has something to tap instead of a blank screen, and
  // flag the response so the frontend can label these honestly as
  // suggestions rather than results.
  let exactMatch = merged.size > 0;
  if (merged.size === 0) {
    for (const cand of rankCompaniesForSearch(q, companies, 4)) {
      merged.set(cand.company.id, { ...enrichCompany(cand.company, companies), matchConfidence: cand.score });
    }
  }

  res.json({ results: [...merged.values()], exact: exactMatch });
});

// GET /api/companies -> dashboard stats + table rows
router.get("/", (req, res) => {
  const companies = store.getCompanies();
  // only show "canonical" companies (not aliases folded into another) in top-level lists
  const canonical = companies.filter((c) => !(c.aliasOf && c.aliasOf.length));
  const enriched = canonical.map((c) => enrichCompany(c, companies));

  const reports = store.getReports();
  const stats = {
    companiesTracked: companies.length,
    verifiedReports: reports.filter((r) => r.verified).length,
    aliasesResolved: companies.filter((c) => c.aliasOf && c.aliasOf.length).length,
    flaggedCount: enriched.filter((c) => c.tier === 2).length,
    confirmedHighRiskCount: enriched.filter((c) => c.tier === 3).length,
    pendingReviewCount: reports.filter((r) => !r.verified).length,
    platformRiskIndex: computePlatformRiskIndex(enriched),
  };

  res.json({ stats, companies: enriched });
});

// GET /api/companies/:id -> full record page data (evidence log, replies)
router.get("/:id", (req, res) => {
  const companies = store.getCompanies();
  const company = companies.find((c) => c.id === req.params.id);
  if (!company) return res.status(404).json({ error: "not found" });

  const reports = store.getReportsForCompany(company.id);
  const enriched = enrichCompany(company, companies);

  res.json({
    ...enriched,
    evidenceLog: reports.map((r) => ({
      id: r.id,
      submittedAt: r.submittedAt,
      summary: r.summary,
      verified: r.verified,
      evidence: r.evidence,
    })),
    companyReply: company.reply || null, // { text, submittedAt } - shown but labeled "unverified"
  });
});

// POST /api/companies/:id/dispute  { contactEmail, replyText }
// Right-of-reply submission. It does NOT post immediately - it queues for
// moderation, same as a student report does, so a company can't post an
// unmoderated rebuttal straight onto its own record.
router.post("/:id/dispute", (req, res) => {
  const { contactEmail, replyText } = req.body || {};
  if (!contactEmail || !replyText) {
    return res.status(400).json({ error: "contactEmail and replyText are required" });
  }

  const companies = store.getCompanies();
  const company = companies.find((c) => c.id === req.params.id);
  if (!company) return res.status(404).json({ error: "not found" });

  // Best-effort check that the contact email's domain matches the company's
  // own domain. This is NOT real verification (no ownership proof, no
  // mailbox confirmation) - it's a weak signal shown to the moderator
  // alongside the dispute, not a gate that lets it skip the queue.
  const emailDomain = contactEmail.split("@")[1]?.toLowerCase() || "";
  const domainLooksLikeCompany = company.domain && emailDomain.includes(company.domain.replace(/^www\./, ""));

  company.pendingReply = {
    text: replyText,
    contactEmail,
    submittedAt: new Date().toISOString().slice(0, 10),
    domainLooksLikeCompany,
  };
  store.saveCompanies(companies);

  res.status(201).json({ status: "pending_review", domainLooksLikeCompany });
});

// GET /api/companies/disputes/queue -> pending right-of-reply submissions
router.get("/disputes/queue", (req, res) => {
  const companies = store.getCompanies();
  const pending = companies
    .filter((c) => c.pendingReply)
    .map((c) => ({ companyId: c.id, companyName: c.name, ...c.pendingReply }));
  res.json({ queue: pending });
});

// POST /api/companies/:id/dispute/approve -> posts the pending reply to the public record
router.post("/:id/dispute/approve", (req, res) => {
  const companies = store.getCompanies();
  const company = companies.find((c) => c.id === req.params.id);
  if (!company || !company.pendingReply) return res.status(404).json({ error: "no pending dispute" });
  company.reply = { text: company.pendingReply.text, submittedAt: company.pendingReply.submittedAt };
  delete company.pendingReply;
  store.saveCompanies(companies);
  res.json({ reply: company.reply });
});

// POST /api/companies/:id/dispute/reject -> discards the pending reply
router.post("/:id/dispute/reject", (req, res) => {
  const companies = store.getCompanies();
  const company = companies.find((c) => c.id === req.params.id);
  if (!company || !company.pendingReply) return res.status(404).json({ error: "no pending dispute" });
  delete company.pendingReply;
  store.saveCompanies(companies);
  res.json({ status: "rejected" });
});

module.exports = router;
