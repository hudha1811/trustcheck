const express = require("express");
const router = express.Router();
const store = require("../src/store");
const { computeTier, computePlatformRiskIndex } = require("../src/scoring");

// GET /api/analysis -> aggregate numbers for charts. All derived from the
// same reports/companies data the dashboard uses - nothing here is a
// separately-tracked metric, it's just sliced a different way.
router.get("/", (req, res) => {
  const companies = store.getCompanies();
  const canonical = companies.filter((c) => !(c.aliasOf && c.aliasOf.length));

  const enriched = canonical.map((c) => {
    const reports = store.getReportsForCompany(c.id);
    return { name: c.name, ...computeTier(reports) };
  });

  const tierCounts = { 0: 0, 1: 0, 2: 0, 3: 0 };
  for (const c of enriched) tierCounts[c.tier]++;

  const allEvidence = store.getReports().flatMap((r) => r.evidence || []);
  const evidenceTypeCounts = {};
  for (const e of allEvidence) evidenceTypeCounts[e.type] = (evidenceTypeCounts[e.type] || 0) + 1;

  res.json({
    tierCounts,
    evidenceTypeCounts,
    platformRiskIndex: computePlatformRiskIndex(enriched),
    totalCanonicalCompanies: canonical.length,
  });
});

module.exports = router;
