const express = require("express");
const router = express.Router();
const crypto = require("crypto");
const store = require("../src/store");

/**
 * Hashes a college email so a submitter's identity is never stored in
 * plaintext, while still letting the system dedupe/count "independent"
 * verified submitters. Swap this for a real domain-verified email flow
 * (e.g. OTP to the .edu/.ac.in address) before going live.
 */
function hashCollegeEmail(email) {
  return "sha_" + crypto.createHash("sha256").update(email.trim().toLowerCase()).digest("hex").slice(0, 8);
}

// POST /api/reports  { companyId, collegeEmail, summary, evidence: [{type,date}] }
// New reports always land unverified/pending review - nothing here auto-publishes.
router.post("/", (req, res) => {
  const { companyId, collegeEmail, summary, evidence } = req.body || {};
  if (!companyId || !collegeEmail || !summary) {
    return res.status(400).json({ error: "companyId, collegeEmail, and summary are required" });
  }

  const companies = store.getCompanies();
  if (!companies.find((c) => c.id === companyId)) {
    return res.status(404).json({ error: "unknown companyId" });
  }

  const reports = store.getReports();
  const newReport = {
    id: "r" + String(reports.length + 1).padStart(3, "0"),
    companyId,
    verifiedStudentHash: hashCollegeEmail(collegeEmail),
    verified: false, // moderation queue must flip this
    submittedAt: new Date().toISOString().slice(0, 10),
    summary,
    evidence: evidence || [],
  };

  reports.push(newReport);
  store.saveReports(reports);

  res.status(201).json({ report: newReport, status: "pending_review" });
});

// GET /api/reports/queue -> moderation queue (unverified reports), with company names attached
router.get("/queue", (req, res) => {
  const companies = store.getCompanies();
  const reports = store.getReports().filter((r) => !r.verified);
  const enriched = reports.map((r) => ({
    ...r,
    companyName: companies.find((c) => c.id === r.companyId)?.name || "(unknown company)",
  }));
  res.json({ queue: enriched });
});

// POST /api/reports/:id/verify -> moderator approves a report (would be auth-gated in production)
router.post("/:id/verify", (req, res) => {
  const reports = store.getReports();
  const report = reports.find((r) => r.id === req.params.id);
  if (!report) return res.status(404).json({ error: "not found" });
  report.verified = true;
  store.saveReports(reports);
  res.json({ report });
});

// POST /api/reports/:id/reject -> moderator rejects and removes a report
router.post("/:id/reject", (req, res) => {
  const reports = store.getReports();
  const idx = reports.findIndex((r) => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "not found" });
  const [removed] = reports.splice(idx, 1);
  store.saveReports(reports);
  res.json({ removed });
});

module.exports = router;
