const express = require("express");
const router = express.Router();
const store = require("../src/store");

// GET /api/evidence  -> every piece of evidence across every company, for the Evidence page.
// Optional ?type=offer_letter / ?verified=true to filter.
router.get("/", (req, res) => {
  const companies = store.getCompanies();
  const reports = store.getReports();

  let rows = [];
  for (const report of reports) {
    const company = companies.find((c) => c.id === report.companyId);
    const companyName = company ? company.name : "(unknown company)";

    if (!report.evidence || !report.evidence.length) {
      // still list the report itself so unsupported claims are visible as such
      rows.push({
        companyId: report.companyId,
        companyName,
        reportId: report.id,
        verified: report.verified,
        summary: report.summary,
        submittedAt: report.submittedAt,
        evidenceType: null,
        evidenceDate: null,
      });
      continue;
    }
    for (const ev of report.evidence) {
      rows.push({
        companyId: report.companyId,
        companyName,
        reportId: report.id,
        verified: report.verified,
        summary: report.summary,
        submittedAt: report.submittedAt,
        evidenceType: ev.type,
        evidenceDate: ev.date,
      });
    }
  }

  if (req.query.type) rows = rows.filter((r) => r.evidenceType === req.query.type);
  if (req.query.verified) rows = rows.filter((r) => String(r.verified) === req.query.verified);

  rows.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));

  res.json({ evidence: rows });
});

module.exports = router;
