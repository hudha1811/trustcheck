const express = require("express");
const router = express.Router();
const store = require("../src/store");
const { hashPassword, verifyPassword, issueToken, publicUser } = require("../src/auth");

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// POST /api/auth/signup  { email, password, college }
router.post("/signup", (req, res) => {
  const { email, password, college } = req.body || {};
  if (!email || !password || !college) {
    return res.status(400).json({ error: "email, password, and college are required" });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: "that doesn't look like a valid email" });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "password must be at least 6 characters" });
  }

  const users = store.getUsers();
  if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: "an account with that email already exists" });
  }

  const { salt, hash } = hashPassword(password);
  const user = {
    id: `u${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    email,
    passwordSalt: salt,
    passwordHash: hash,
    college,
    createdAt: new Date().toISOString(),
    token: issueToken(),
  };
  users.push(user);
  store.saveUsers(users);

  res.status(201).json({ token: user.token, user: publicUser(user) });
});

// POST /api/auth/login  { email, password }
router.post("/login", (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: "email and password are required" });
  }

  const users = store.getUsers();
  const user = users.find((u) => u.email.toLowerCase() === (email || "").toLowerCase());
  if (!user || !verifyPassword(password, user.passwordSalt, user.passwordHash)) {
    // deliberately the same message for "no such user" and "wrong password"
    // so login can't be used to enumerate which emails have accounts
    return res.status(401).json({ error: "incorrect email or password" });
  }

  user.token = issueToken();
  store.saveUsers(users);

  res.json({ token: user.token, user: publicUser(user) });
});

// GET /api/auth/me  (Authorization: Bearer <token>)
router.get("/me", (req, res) => {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: "missing token" });

  const users = store.getUsers();
  const user = users.find((u) => u.token === token);
  if (!user) return res.status(401).json({ error: "invalid or expired token" });

  res.json({ user: publicUser(user) });
});

// PATCH /api/auth/avatar  { avatar: "data:image/jpeg;base64,..." }
// Saves the captured "pose please" photo as the user's icon. Best-effort
// from the client's point of view - the browser already caches the photo
// in localStorage, so a failure here just means it isn't synced to other
// devices yet.
router.patch("/avatar", (req, res) => {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: "missing token" });

  const { avatar } = req.body || {};
  if (!avatar || typeof avatar !== "string" || !avatar.startsWith("data:image/")) {
    return res.status(400).json({ error: "avatar must be a data URL image" });
  }
  // rough cap so one photo can't balloon the flat-file store - a 320x320
  // JPEG capture comfortably fits well under this
  if (avatar.length > 2_000_000) {
    return res.status(413).json({ error: "that photo is too large - try again" });
  }

  const users = store.getUsers();
  const user = users.find((u) => u.token === token);
  if (!user) return res.status(401).json({ error: "invalid or expired token" });

  user.avatar = avatar;
  store.saveUsers(users);

  res.json({ user: publicUser(user) });
});

module.exports = router;
