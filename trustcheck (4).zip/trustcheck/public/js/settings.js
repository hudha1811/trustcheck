const STORAGE_KEY = "trustcheck_compact_view";

async function loadThresholds() {
  const res = await fetch("/api/settings");
  const s = await res.json();
  document.getElementById("thresholds").innerHTML = `
    <div class="stat-row">
      <div class="stat-num">${s.entityResolution.matchThreshold}</div>
      <div class="stat-label">Auto-match confidence threshold</div>
      <div class="stat-sub">Similarity score at/above this is treated as a confident alias match</div>
    </div>
    <div class="stat-row">
      <div class="stat-num">${s.entityResolution.reviewThreshold}</div>
      <div class="stat-label">Ambiguous-match threshold</div>
      <div class="stat-sub">Below the match threshold but at/above this — queued for human review</div>
    </div>
    <div class="stat-row">
      <div class="stat-num">${s.scoring.timeWindowDays}</div>
      <div class="stat-label">Time window (days)</div>
      <div class="stat-sub">Minimum spacing between independent reports for the volume-based Tier 3 rule</div>
    </div>
  `;
}

const toggle = document.getElementById("compactToggle");
toggle.checked = localStorage.getItem(STORAGE_KEY) === "true";
toggle.addEventListener("change", () => {
  localStorage.setItem(STORAGE_KEY, toggle.checked);
});

loadThresholds();
