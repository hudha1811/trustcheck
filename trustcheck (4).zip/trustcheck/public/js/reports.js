async function loadReportQueue() {
  const box = document.getElementById("reportQueue");
  const res = await fetch("/api/reports/queue");
  const { queue } = await res.json();

  if (!queue.length) {
    box.innerHTML = `<div class="company-sub">Nothing pending.</div>`;
    return;
  }

  box.innerHTML = queue.map((r) => `
    <div class="evidence-item">
      <div class="eitype">${r.companyName} · filed ${r.submittedAt}</div>
      <div class="esummary">${r.summary}</div>
      ${r.evidence.length
        ? `<div class="tags">${r.evidence.map((e) => `<span class="tag">${e.type.replace(/_/g, " ")}</span>`).join("")}</div>`
        : `<div class="edate">No documentary evidence attached</div>`}
      <div class="cta-row" style="margin-top:10px;">
        <button class="cta primary" data-action="verify" data-id="${r.id}">Verify</button>
        <button class="cta" data-action="reject" data-id="${r.id}">Reject</button>
      </div>
    </div>
  `).join("");

  box.querySelectorAll("button[data-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const { action, id } = btn.dataset;
      await fetch(`/api/reports/${id}/${action}`, { method: "POST" });
      loadReportQueue();
    });
  });
}

async function loadDisputeQueue() {
  const box = document.getElementById("disputeQueue");
  const res = await fetch("/api/companies/disputes/queue");
  const { queue } = await res.json();

  if (!queue.length) {
    box.innerHTML = `<div class="company-sub">Nothing pending.</div>`;
    return;
  }

  box.innerHTML = queue.map((d) => `
    <div class="evidence-item">
      <div class="eitype">${d.companyName} · submitted ${d.submittedAt}</div>
      <div class="esummary">${d.text}</div>
      <div class="tags">
        <span class="tag">from ${d.contactEmail}</span>
        <span class="tag">${d.domainLooksLikeCompany ? "email domain matches company" : "email domain does NOT match company - review closely"}</span>
      </div>
      <div class="cta-row" style="margin-top:10px;">
        <button class="cta primary" data-action="approve" data-id="${d.companyId}">Approve &amp; post</button>
        <button class="cta" data-action="reject" data-id="${d.companyId}">Reject</button>
      </div>
    </div>
  `).join("");

  box.querySelectorAll("button[data-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const { action, id } = btn.dataset;
      await fetch(`/api/companies/${id}/dispute/${action}`, { method: "POST" });
      loadDisputeQueue();
    });
  });
}

loadReportQueue();
loadDisputeQueue();
