async function loadEvidence() {
  const tableCard = document.querySelector(".table-card");
  if (localStorage.getItem("trustcheck_compact_view") === "true") tableCard.classList.add("compact");

  const type = document.getElementById("typeFilter").value;
  const verifiedOnly = document.getElementById("verifiedOnly").checked;

  const params = new URLSearchParams();
  if (type) params.set("type", type);
  if (verifiedOnly) params.set("verified", "true");

  const res = await fetch(`/api/evidence?${params}`);
  const { evidence } = await res.json();

  const tbody = document.getElementById("evidenceBody");
  if (!evidence.length) {
    tbody.innerHTML = `<tr><td colspan="5" class="company-sub">No matching evidence.</td></tr>`;
    return;
  }

  tbody.innerHTML = evidence.map((e) => `
    <tr>
      <td><div class="company-name">${e.companyName}</div></td>
      <td>${e.evidenceType ? e.evidenceType.replace(/_/g, " ") : "<span class=\"company-sub\">none attached</span>"}</td>
      <td>${e.evidenceDate || e.submittedAt}</td>
      <td>${e.verified ? "Verified" : "Pending review"}</td>
      <td class="company-sub">${e.summary}</td>
    </tr>
  `).join("");
}

document.getElementById("typeFilter").addEventListener("change", loadEvidence);
document.getElementById("verifiedOnly").addEventListener("change", loadEvidence);

loadEvidence();
