const params = new URLSearchParams(window.location.search);
const companyId = params.get("id");

const TIER_LABEL = { 0: "Insufficient data", 1: "Unverified", 2: "Flagged", 3: "Confirmed high risk" };

async function loadCompany() {
  if (!companyId) {
    document.getElementById("rName").textContent = "No company selected.";
    return;
  }
  const res = await fetch(`/api/companies/${companyId}`);
  if (!res.ok) {
    document.getElementById("rName").textContent = "Company not found.";
    return;
  }
  const c = await res.json();

  document.getElementById("rName").textContent = c.name;
  document.getElementById("rAliases").innerHTML = c.aliases.length
    ? `<span>Also listed as:</span> ${c.aliases.join(", ")}`
    : "";

  document.getElementById("rTier").textContent = TIER_LABEL[c.tier];
  document.getElementById("rReason").textContent = c.reason;

  document.getElementById("rTags").innerHTML = `
    <span class="tag">${c.independentReportCount} independent report(s)</span>
    <span class="tag">${c.documentaryEvidenceCount} with documentary evidence</span>
    <span class="tag">${c.totalReportsFiled} total filed (incl. unverified)</span>
  `;

  if (c.companyReply) {
    document.getElementById("replyBox").style.display = "block";
    document.getElementById("replyText").textContent = c.companyReply.text;
  }

  const log = document.getElementById("evidenceLog");
  if (!c.evidenceLog.length) {
    log.innerHTML = `<div class="company-sub">No reports filed yet.</div>`;
  } else {
    log.innerHTML = c.evidenceLog.map((r) => `
      <div class="evidence-item">
        <div class="eitype">${r.verified ? "Verified report" : "Pending review"} · ${r.submittedAt}</div>
        <div class="esummary">${r.summary}</div>
        ${r.evidence.length
          ? `<div class="tags">${r.evidence.map((e) => `<span class="tag">${e.type.replace(/_/g, " ")}</span>`).join("")}</div>`
          : `<div class="edate">No documentary evidence attached</div>`}
      </div>
    `).join("");
  }
}

document.getElementById("newReportForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const status = document.getElementById("formStatus");
  status.textContent = "Submitting…";

  const body = {
    companyId,
    collegeEmail: document.getElementById("fEmail").value,
    summary: document.getElementById("fSummary").value,
    evidence: [],
  };

  const res = await fetch("/api/reports", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (res.ok) {
    status.textContent = "Submitted. It will appear once it clears moderation review.";
    e.target.reset();
  } else {
    const err = await res.json();
    status.textContent = `Error: ${err.error}`;
  }
});

document.getElementById("newDisputeForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const status = document.getElementById("disputeStatus");
  status.textContent = "Submitting…";

  const body = {
    contactEmail: document.getElementById("dEmail").value,
    replyText: document.getElementById("dText").value,
  };

  const res = await fetch(`/api/companies/${companyId}/dispute`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (res.ok) {
    status.textContent = "Submitted. It will appear on this page once a moderator approves it.";
    e.target.reset();
  } else {
    const err = await res.json();
    status.textContent = `Error: ${err.error}`;
  }
});

loadCompany();
