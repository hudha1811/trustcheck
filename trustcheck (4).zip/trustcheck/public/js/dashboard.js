const RING_CIRCUMFERENCE = 264; // 2 * PI * r42, matches the SVG r="42" circles

/** percent: 0-100. Sets stroke-dashoffset on the given <circle> so it fills clockwise. */
function setRing(circleEl, labelEl, percent) {
  const clamped = Math.max(0, Math.min(100, percent));
  const offset = RING_CIRCUMFERENCE * (1 - clamped / 100);
  circleEl.setAttribute("stroke-dashoffset", offset.toFixed(1));
  if (labelEl) labelEl.textContent = `${Math.round(clamped)}%`;
}

function tierBadgeClass(tier) {
  return `tier-badge tier-${tier}`;
}

function tierName(tier) {
  return { 0: "Insufficient data", 1: "Unverified", 2: "Flagged", 3: "Confirmed high risk" }[tier] ?? "—";
}

async function loadDashboard() {
  // client-side guard only - see login.html's note on what real auth
  // still needs (server-enforced sessions, not just a token in localStorage)
  if (!localStorage.getItem("trustcheck_token")) {
    window.location.href = "login.html";
    return;
  }
  // sign-out is now wired by the shared topbar (js/topbar.js)

  const tableCard = document.querySelector(".table-card");
  if (localStorage.getItem("trustcheck_compact_view") === "true") tableCard.classList.add("compact");

  const res = await fetch("/api/companies");
  const { stats, companies } = await res.json();

  document.getElementById("statCompanies").textContent = stats.companiesTracked;
  document.getElementById("statReports").textContent = stats.verifiedReports;
  document.getElementById("statAliases").textContent = stats.aliasesResolved;

  const flaggedPct = stats.companiesTracked ? (stats.flaggedCount / stats.companiesTracked) * 100 : 0;
  const pendingPct = stats.verifiedReports + stats.pendingReviewCount
    ? (stats.pendingReviewCount / (stats.verifiedReports + stats.pendingReviewCount)) * 100
    : 0;

  setRing(document.getElementById("ringFlagged"), document.getElementById("labelFlagged"), flaggedPct);
  setRing(document.getElementById("ringPending"), document.getElementById("labelPending"), pendingPct);
  setRing(document.getElementById("ringRisk"), document.getElementById("labelRisk"), stats.platformRiskIndex);

  // Shield: share of tracked companies at Tier 3
  const highRiskPct = stats.companiesTracked ? (stats.confirmedHighRiskCount / stats.companiesTracked) * 100 : 0;
  const shieldFill = document.getElementById("shieldFill");
  const shieldCircumference = 330;
  shieldFill.setAttribute("stroke-dashoffset", (shieldCircumference * (1 - highRiskPct / 100)).toFixed(1));
  document.getElementById("shieldNum").textContent = stats.confirmedHighRiskCount;

  // Pipeline health has no real telemetry yet in this prototype -
  // left as an explicit placeholder rather than a faked number.
  setRing(document.getElementById("ringAutoMatch"), document.getElementById("labelAutoMatch"), 0);
  document.getElementById("labelAutoMatch").textContent = "n/a";
  setRing(document.getElementById("ringSla"), document.getElementById("labelSla"), 0);
  document.getElementById("labelSla").textContent = "n/a";

  const tbody = document.getElementById("companyTableBody");
  const filter = new URLSearchParams(window.location.search).get("filter");
  const rows = filter === "flagged" ? companies.filter((c) => c.tier >= 2) : companies;
  if (filter === "flagged") document.getElementById("filterNotice").style.display = "block";

  tbody.innerHTML = rows.map((c) => `
    <tr>
      <td>
        <div class="company-name">${c.name}</div>
        ${c.aliases.length ? `<div class="company-sub">Also listed as: ${c.aliases.join(", ")}</div>` : ""}
      </td>
      <td><span class="${tierBadgeClass(c.tier)}">${tierName(c.tier)}</span></td>
      <td>${c.independentReportCount}</td>
      <td class="company-sub">${c.reason}</td>
      <td><button class="details-btn" onclick="window.location.href='company.html?id=${c.id}'">See details</button></td>
    </tr>
  `).join("");
}

function renderSearchResults(results, exact, query) {
  const box = document.getElementById("searchResults");

  if (!results.length) {
    // Database is genuinely empty - the one true dead end.
    box.innerHTML = `<div class="search-empty">No companies tracked yet.</div>`;
    box.hidden = false;
    return;
  }

  const header = !exact
    ? `<div class="search-hint">Not tracked under that name yet — closest matches in our database:</div>`
    : "";

  box.innerHTML = header + results.map((r) => `
    <div class="search-result-item" onclick="window.location.href='company.html?id=${r.id}'">
      <div class="srn">${r.name}${r.matchConfidence ? ` <span style="color:var(--text-dim);font-weight:400">— did you mean this? (${Math.round(r.matchConfidence * 100)}% match)</span>` : ""}</div>
      <div class="srs">Tier: ${tierName(r.tier)} · ${r.independentReportCount} independent report(s)</div>
    </div>
  `).join("") + (!exact ? `<div class="search-footer">Don't see the right one? It may not be tracked yet.</div>` : "");

  box.hidden = false;
}

let searchDebounce;
document.getElementById("searchInput").addEventListener("input", (e) => {
  clearTimeout(searchDebounce);
  const q = e.target.value.trim();
  const box = document.getElementById("searchResults");
  if (!q) { box.hidden = true; return; }
  searchDebounce = setTimeout(async () => {
    const res = await fetch(`/api/companies/search?q=${encodeURIComponent(q)}`);
    const { results, exact } = await res.json();
    renderSearchResults(results, exact, q);
  }, 250);
});

loadDashboard();
