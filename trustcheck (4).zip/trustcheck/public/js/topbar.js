// Shared topbar (avatar / notifications / sign out), mounted into
// <div id="topbar-mount"></div> on every dashboard page. Keeps the icon
// row in one place instead of copy-pasted markup per page.
(function () {
  const POSE_LINES = [
    "pose please 📸",
    "say cheese!",
    "strike a pose 🕺",
    "smile — this is your icon now",
  ];

  function getCachedAvatar() {
    return localStorage.getItem("trustcheck_avatar") || "";
  }
  function setCachedAvatar(dataUrl) {
    if (dataUrl) localStorage.setItem("trustcheck_avatar", dataUrl);
    else localStorage.removeItem("trustcheck_avatar");
  }

  function buildTopbar(mount, opts) {
    opts = opts || {};
    const cached = getCachedAvatar();

    const wrap = document.createElement("div");
    wrap.className = "topbar-icons";
    wrap.style.display = "flex";
    wrap.style.alignItems = "center";
    wrap.style.gap = "14px";

    wrap.innerHTML = `
      <div class="icon-btn" id="tb-bell" title="Notifications"><i class="ti ti-bell"></i></div>
      <button type="button" class="avatar-btn" id="tb-avatar" title="Your photo">
        ${cached
          ? `<img src="${cached}" alt="Your avatar">`
          : `<i class="ti ti-user"></i>`}
        <span class="avatar-edit-dot"><i class="ti ti-camera" style="font-size:8px;"></i></span>
      </button>
      <a class="icon-btn" href="login.html" id="tb-signout" title="Sign out" style="text-decoration:none;"><i class="ti ti-logout"></i></a>
    `;
    mount.appendChild(wrap);

    wrap.querySelector("#tb-signout").addEventListener("click", () => {
      localStorage.removeItem("trustcheck_token");
      localStorage.removeItem("trustcheck_email");
      localStorage.removeItem("trustcheck_college");
    });

    wrap.querySelector("#tb-avatar").addEventListener("click", () => {
      openAvatarModal({ allowSkip: true });
    });
  }

  // -------- Avatar capture modal (webcam -> canvas -> dataURL) --------
  let modalEl = null;
  let streamRef = null;
  let capturedDataUrl = null;

  function ensureModal() {
    if (modalEl) return modalEl;
    modalEl = document.createElement("div");
    modalEl.className = "avatar-modal-backdrop";
    modalEl.innerHTML = `
      <div class="avatar-modal">
        <h2>Set your icon</h2>
        <div class="avatar-prompt" id="am-prompt"></div>
        <div class="avatar-error" id="am-error"></div>
        <div class="avatar-stage" id="am-stage">
          <div class="avatar-placeholder" id="am-placeholder">Camera access needed — tap "Open camera" to start.</div>
        </div>
        <div class="avatar-actions" id="am-actions">
          <button type="button" class="avatar-btn-primary" id="am-open">Open camera</button>
        </div>
        <button type="button" class="avatar-skip" id="am-skip">Not now</button>
      </div>
    `;
    document.body.appendChild(modalEl);

    modalEl.addEventListener("click", (e) => {
      if (e.target === modalEl) closeAvatarModal();
    });
    modalEl.querySelector("#am-skip").addEventListener("click", closeAvatarModal);

    return modalEl;
  }

  function stopStream() {
    if (streamRef) {
      streamRef.getTracks().forEach((t) => t.stop());
      streamRef = null;
    }
  }

  function showError(msg) {
    const errEl = modalEl.querySelector("#am-error");
    errEl.textContent = msg;
    errEl.classList.add("show");
  }

  function resetToOpenState() {
    const stage = modalEl.querySelector("#am-stage");
    const actions = modalEl.querySelector("#am-actions");
    stage.innerHTML = `<div class="avatar-placeholder" id="am-placeholder">Camera access needed — tap "Open camera" to start.</div>`;
    actions.innerHTML = `<button type="button" class="avatar-btn-primary" id="am-open">Open camera</button>`;
    actions.querySelector("#am-open").addEventListener("click", startCamera);
  }

  async function startCamera() {
    const stage = modalEl.querySelector("#am-stage");
    const actions = modalEl.querySelector("#am-actions");
    modalEl.querySelector("#am-error").classList.remove("show");

    try {
      streamRef = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
    } catch (err) {
      showError("Couldn't reach your camera — check permissions, or skip for now.");
      return;
    }

    stage.innerHTML = `<video id="am-video" autoplay playsinline muted></video>`;
    const video = stage.querySelector("#am-video");
    video.srcObject = streamRef;

    actions.innerHTML = `<button type="button" class="avatar-btn-primary" id="am-capture">Capture</button>`;
    actions.querySelector("#am-capture").addEventListener("click", () => capture(video));
  }

  function capture(video) {
    const stage = modalEl.querySelector("#am-stage");
    stage.classList.add("flash");
    setTimeout(() => stage.classList.remove("flash"), 350);

    const canvas = document.createElement("canvas");
    const size = Math.min(video.videoWidth, video.videoHeight) || 320;
    canvas.width = 320;
    canvas.height = 320;
    const ctx = canvas.getContext("2d");
    // mirror to match the preview, and crop to a centered square
    const sx = (video.videoWidth - size) / 2;
    const sy = (video.videoHeight - size) / 2;
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, sx, sy, size, size, 0, 0, canvas.width, canvas.height);
    capturedDataUrl = canvas.toDataURL("image/jpeg", 0.85);

    stopStream();
    stage.innerHTML = `<img src="${capturedDataUrl}" alt="Captured photo" style="transform:none;">`;

    const actions = modalEl.querySelector("#am-actions");
    actions.innerHTML = `
      <button type="button" class="avatar-btn-ghost" id="am-retake">Retake</button>
      <button type="button" class="avatar-btn-primary" id="am-save">Use this</button>
    `;
    actions.querySelector("#am-retake").addEventListener("click", () => {
      capturedDataUrl = null;
      startCamera();
    });
    actions.querySelector("#am-save").addEventListener("click", saveAvatar);
  }

  async function saveAvatar() {
    if (!capturedDataUrl) return;
    const saveBtn = modalEl.querySelector("#am-save");
    if (saveBtn) {
      saveBtn.disabled = true;
      saveBtn.textContent = "Saving…";
    }

    setCachedAvatar(capturedDataUrl);
    document.querySelectorAll("#tb-avatar").forEach((btn) => {
      btn.innerHTML = `<img src="${capturedDataUrl}" alt="Your avatar"><span class="avatar-edit-dot"><i class="ti ti-camera" style="font-size:8px;"></i></span>`;
    });

    // best-effort sync to the backend so the avatar isn't only on this
    // device/browser — silently ignored if it fails, since the cached
    // copy in localStorage is what the UI actually reads from
    const token = localStorage.getItem("trustcheck_token");
    if (token) {
      try {
        await fetch("/api/auth/avatar", {
          method: "PATCH",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({ avatar: capturedDataUrl }),
        });
      } catch (err) {
        // offline or server down — fine, we already have it cached locally
      }
    }

    closeAvatarModal();
  }

  let onDoneCallback = null;

  function openAvatarModal(opts) {
    opts = opts || {};
    onDoneCallback = typeof opts.onDone === "function" ? opts.onDone : null;
    ensureModal();
    capturedDataUrl = null;
    modalEl.querySelector("#am-prompt").textContent =
      opts.prompt || POSE_LINES[Math.floor(Math.random() * POSE_LINES.length)];
    modalEl.querySelector("#am-error").classList.remove("show");
    resetToOpenState();
    modalEl.classList.add("show");
    modalEl.querySelector("#am-open").addEventListener("click", startCamera);
  }

  function closeAvatarModal() {
    if (!modalEl) return;
    stopStream();
    modalEl.classList.remove("show");
    const cb = onDoneCallback;
    onDoneCallback = null;
    if (cb) cb(getCachedAvatar());
  }

  window.TrustCheckTopbar = { buildTopbar, openAvatarModal, getCachedAvatar };

  document.addEventListener("DOMContentLoaded", () => {
    const mount = document.getElementById("topbar-mount");
    if (mount) buildTopbar(mount);
  });
})();
