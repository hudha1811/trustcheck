const TIER_LABEL = { 0: "Insufficient data", 1: "Unverified", 2: "Flagged", 3: "Confirmed high risk" };

function renderBars(containerId, entries) {
  const max = Math.max(1, ...entries.map(([, v]) => v));
  document.getElementById(containerId).innerHTML = entries.map(([label, value]) => `
    <div class="bar-row">
      <div class="bar-label">${label}</div>
      <div class="bar-track"><div class="bar-fill" style="width:${(value / max) * 100}%"></div></div>
      <div class="bar-value">${value}</div>
    </div>
  `).join("");
}

async function loadAnalysis() {
  const res = await fetch("/api/analysis");
  const { tierCounts, evidenceTypeCounts } = await res.json();

  renderBars("tierBars", Object.entries(tierCounts).map(([tier, count]) => [TIER_LABEL[tier], count]));

  const evidenceEntries = Object.entries(evidenceTypeCounts).map(([type, count]) => [type.replace(/_/g, " "), count]);
  if (!evidenceEntries.length) {
    document.getElementById("evidenceBars").innerHTML = `<div class="company-sub">No evidence submitted yet.</div>`;
  } else {
    renderBars("evidenceBars", evidenceEntries);
  }
}

loadAnalysis();
