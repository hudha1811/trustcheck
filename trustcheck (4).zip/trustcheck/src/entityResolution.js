/**
 * Entity resolution: decides whether two company records are likely the
 * same underlying entity operating under different names, based on
 * scrapeable signals only (name, domain, registered address).
 *
 * IMPORTANT: this module never auto-merges. It returns a confidence score
 * and a verdict ("match" | "review" | "no_match"). Anything in the
 * "review" band must be queued for a human, per the scope boundary in the
 * problem statement (no auto-published accusations).
 */

const MATCH_THRESHOLD = 0.85;   // >= this -> confident match, still shown to a human before merge
const REVIEW_THRESHOLD = 0.55;  // >= this and < MATCH_THRESHOLD -> ambiguous, queue for review

/** Levenshtein edit distance between two strings. */
function levenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost
      );
    }
  }
  return dp[m][n];
}

/** Normalized similarity in [0, 1], 1 = identical. */
function stringSimilarity(a, b) {
  if (!a || !b) return 0;
  const dist = levenshtein(a, b);
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 1;
  return 1 - dist / maxLen;
}

/** Strips common suffixes/noise so "Bright Future Edtech Pvt Ltd" ~ "Bright Future EdTech". */
function normalizeName(name) {
  return name
    .toLowerCase()
    .replace(/\b(pvt\.?|private|ltd\.?|limited|llp|inc\.?|technologies|technology|solutions|learning|edtech|education)\b/g, "")
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeDomain(domain) {
  if (!domain) return "";
  return domain.toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/$/, "");
}

function normalizeAddress(address) {
  if (!address) return "";
  return address.toLowerCase().replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim();
}

/**
 * Compares two company records and returns:
 *   { score: 0..1, verdict: "match" | "review" | "no_match", signals: {...} }
 *
 * Weighting: domain match is the strongest signal (companies rarely share
 * a domain by coincidence), name similarity is the primary text signal,
 * address similarity is corroborating but weak alone (shared office
 * buildings/coworking spaces produce false positives).
 */
function compareCompanies(a, b) {
  const nameSim = stringSimilarity(normalizeName(a.name), normalizeName(b.name));

  const domainA = normalizeDomain(a.domain);
  const domainB = normalizeDomain(b.domain);
  const domainMatch = domainA && domainB && domainA === domainB ? 1 : 0;

  const addrSim = stringSimilarity(normalizeAddress(a.address), normalizeAddress(b.address));

  // Optional strong signal if you later integrate MCA lookups (GSTIN/CIN).
  const registryMatch =
    a.gstin && b.gstin ? (a.gstin === b.gstin ? 1 : 0) : null;

  let score;
  if (registryMatch === 1) {
    score = 1; // government registry ID match is authoritative
  } else if (registryMatch === 0) {
    score = 0; // different registered entities, don't let name similarity override this
  } else {
    score = nameSim * 0.55 + domainMatch * 0.35 + addrSim * 0.1;
  }

  let verdict = "no_match";
  if (score >= MATCH_THRESHOLD) verdict = "match";
  else if (score >= REVIEW_THRESHOLD) verdict = "review";

  return {
    score: Number(score.toFixed(3)),
    verdict,
    signals: { nameSim: Number(nameSim.toFixed(3)), domainMatch, addrSim: Number(addrSim.toFixed(3)), registryMatch },
  };
}

/**
 * Given a new/incoming company record and the existing set of companies,
 * returns the best candidate matches sorted by score, for the
 * "did you mean X?" confidence-scored search / alias suggestion flow.
 */
function findCandidateMatches(incoming, existingCompanies, limit = 5) {
  return existingCompanies
    .map((c) => ({ company: c, ...compareCompanies(incoming, c) }))
    .filter((r) => r.verdict !== "no_match")
    .sort((x, y) => y.score - x.score)
    .slice(0, limit);
}

/**
 * Lenient ranking for the search box - deliberately separate from
 * compareCompanies/findCandidateMatches above. Those exist to decide
 * whether two DB records should be flagged for a human to merge, so they
 * stay strict (MATCH_THRESHOLD/REVIEW_THRESHOLD) on purpose. Search just
 * needs to help a student find the company they're typing, including
 * partial words ("bright") and typos - so it scores on token containment
 * first, whole-string edit distance second.
 */
function searchRank(query, name) {
  const q = normalizeName(query);
  const n = normalizeName(name);
  if (!q || !n) return 0;

  const qTokens = q.split(" ").filter(Boolean);
  const nTokens = n.split(" ").filter(Boolean);
  // Containment counts as a hit, but is weighted by how much of the two
  // tokens actually overlap - "interns" inside "internshala" is a partial
  // hit (7 of 11 chars), not a perfect one, so it shouldn't read as 100%.
  const tokenHitScores = qTokens.map((qt) => {
    const best = nTokens.reduce((max, nt) => {
      if (nt === qt) return 1;
      if (nt.includes(qt) || qt.includes(nt)) {
        return Math.max(max, Math.min(qt.length, nt.length) / Math.max(qt.length, nt.length));
      }
      return max;
    }, 0);
    return best;
  });
  const tokenScore = qTokens.length ? tokenHitScores.reduce((a, b) => a + b, 0) / qTokens.length : 0;

  const wholeStringScore = stringSimilarity(q, n);

  return Math.max(tokenScore, wholeStringScore * 0.9);
}

/**
 * Ranks every company against a free-text query for the search box.
 * Always returns the closest companies (even a weak match) rather than
 * an empty list, so the UI has something to prompt with instead of a
 * dead "no results" - the caller decides how to label low-confidence
 * results.
 */
function rankCompaniesForSearch(query, companies, limit = 5) {
  return companies
    .map((c) => ({ company: c, score: searchRank(query, c.name) }))
    .sort((x, y) => y.score - x.score)
    .slice(0, limit);
}

module.exports = {
  compareCompanies,
  findCandidateMatches,
  searchRank,
  rankCompaniesForSearch,
  normalizeName,
  normalizeDomain,
  normalizeAddress,
  MATCH_THRESHOLD,
  REVIEW_THRESHOLD,
};
