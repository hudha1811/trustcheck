/**
 * Scoring engine.
 *
 * Rubric (as decided in the design phase):
 *   Tier 0 "insufficient"     -> 0 verified reports
 *   Tier 1 "unverified"       -> 1 verified report
 *   Tier 2 "flagged"          -> 2+ independent verified reports, at least
 *                                one with documentary evidence
 *   Tier 3 "confirmed high risk" ->
 *       3+ independent verified reports spread across separate time
 *       windows (not all filed in one burst), OR
 *       1 report with strong documentary evidence (offer letter AND
 *       payment/stipend records)
 *
 * "Independent" = distinct, unlinked submitters (deduped by
 * verifiedStudentHash). A single aggrieved student re-submitting cannot
 * inflate a company's tier.
 *
 * Every tier calculation returns the exact evidence count that produced
 * it, because the transparency of "why this tier" is what makes the
 * public record defensible.
 */

const STRONG_EVIDENCE_TYPES = new Set(["offer_letter", "payment_record", "appointment_letter"]);
const TIME_WINDOW_DAYS = 30; // reports must span windows this size apart to count as "separate"

function daysBetween(a, b) {
  return Math.abs(new Date(a) - new Date(b)) / (1000 * 60 * 60 * 24);
}

/** Dedupe reports to one-per-submitter (independence rule). */
function independentReports(reports) {
  const seen = new Map();
  for (const r of reports) {
    if (!r.verifiedStudentHash) continue; // unverified submitter identity, can't count toward independence
    if (!seen.has(r.verifiedStudentHash)) seen.set(r.verifiedStudentHash, r);
  }
  return [...seen.values()];
}

function hasStrongDocumentaryEvidence(report) {
  const types = new Set(report.evidence?.map((e) => e.type) || []);
  return types.has("offer_letter") && types.has("payment_record");
}

function hasAnyDocumentaryEvidence(report) {
  return (report.evidence || []).some((e) => STRONG_EVIDENCE_TYPES.has(e.type));
}

/** Do the independent reports span at least two separate time windows? */
function spansSeparateWindows(reports) {
  if (reports.length < 2) return false;
  const dates = reports.map((r) => new Date(r.submittedAt)).sort((a, b) => a - b);
  for (let i = 1; i < dates.length; i++) {
    if (daysBetween(dates[i], dates[0]) >= TIME_WINDOW_DAYS) return true;
  }
  return false;
}

/**
 * Computes a company's tier from its verified reports.
 * `reports` should already be filtered to this company's alias group
 * (i.e. entity resolution has already merged aliases upstream).
 */
function computeTier(reports) {
  const verified = (reports || []).filter((r) => r.verified);
  const independent = independentReports(verified);
  const evidenceCount = independent.filter(hasAnyDocumentaryEvidence).length;

  const tier3ByStrongEvidence = independent.some(hasStrongDocumentaryEvidence);
  const tier3ByVolume = independent.length >= 3 && spansSeparateWindows(independent);

  let tier, label, reason;

  if (tier3ByStrongEvidence || tier3ByVolume) {
    tier = 3;
    label = "confirmed_high_risk";
    reason = tier3ByStrongEvidence
      ? "1 independent report with offer letter + payment records"
      : `${independent.length} independent reports across separate time windows`;
  } else if (independent.length >= 2 && evidenceCount >= 1) {
    tier = 2;
    label = "flagged";
    reason = `${independent.length} independent reports, ${evidenceCount} with documentary evidence`;
  } else if (independent.length >= 1) {
    tier = 1;
    label = "unverified";
    reason = `${independent.length} independent report, evidence pending review`;
  } else {
    tier = 0;
    label = "insufficient_data";
    reason = "no verified independent reports yet";
  }

  return {
    tier,
    label,
    reason,
    independentReportCount: independent.length,
    documentaryEvidenceCount: evidenceCount,
    totalReportsFiled: (reports || []).length,
  };
}

/** Platform-wide "risk index" shown on the dashboard gauge, 0-100. */
function computePlatformRiskIndex(allCompanies) {
  if (!allCompanies.length) return 0;
  const flaggedOrWorse = allCompanies.filter((c) => c.tier >= 2).length;
  return Math.round((flaggedOrWorse / allCompanies.length) * 100);
}

module.exports = { computeTier, computePlatformRiskIndex, TIME_WINDOW_DAYS };
