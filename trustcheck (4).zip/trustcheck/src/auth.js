/**
 * Auth helpers for the prototype user store.
 *
 * Passwords are hashed with Node's built-in crypto.scrypt (salted,
 * per-user) - never stored in plaintext. This deliberately avoids adding
 * a new npm dependency (bcrypt etc.) since the project already had
 * install friction; scrypt via the standard library is a reasonable
 * password hash without pulling in anything extra.
 *
 * Sessions are a random token stored on the user record itself (not a
 * separate in-memory session table), so a login survives a server
 * restart - consistent with the rest of this app being a flat-file
 * store rather than a real database. This is NOT a substitute for
 * signed, httpOnly cookies in a real deployment; see the note on the
 * login page and README for what's still missing before this is real
 * auth.
 */

const crypto = require("crypto");

const SCRYPT_KEYLEN = 64;

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, SCRYPT_KEYLEN).toString("hex");
  return { salt, hash };
}

function verifyPassword(password, salt, hash) {
  const attempt = crypto.scryptSync(password, salt, SCRYPT_KEYLEN).toString("hex");
  // timing-safe compare so login can't be brute-forced via response-time
  const a = Buffer.from(attempt, "hex");
  const b = Buffer.from(hash, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function issueToken() {
  return crypto.randomBytes(24).toString("hex");
}

/** Strips password fields before a user record ever leaves the server. */
function publicUser(user) {
  return {
    id: user.id,
    email: user.email,
    college: user.college,
    createdAt: user.createdAt,
    avatar: user.avatar || null,
  };
}

module.exports = { hashPassword, verifyPassword, issueToken, publicUser };
