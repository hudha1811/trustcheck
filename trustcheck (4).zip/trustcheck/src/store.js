/**
 * Prototype data layer.
 *
 * This is a flat-file JSON store, NOT a real database. It exists so the
 * rest of the app (entity resolution, scoring, routes) is already
 * structured the way it will be once this is swapped for Postgres/SQLite:
 * every read/write goes through this module, nothing else touches the
 * files directly. Swapping the backend later means rewriting this file
 * only.
 */

const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "..", "data");
const COMPANIES_FILE = path.join(DATA_DIR, "companies.json");
const REPORTS_FILE = path.join(DATA_DIR, "reports.json");
const USERS_FILE = path.join(DATA_DIR, "users.json");

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf-8"));
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function getCompanies() {
  return readJson(COMPANIES_FILE);
}

function saveCompanies(companies) {
  writeJson(COMPANIES_FILE, companies);
}

function getReports() {
  return readJson(REPORTS_FILE);
}

function saveReports(reports) {
  writeJson(REPORTS_FILE, reports);
}

function getReportsForCompany(companyId) {
  const companies = getCompanies();
  const company = companies.find((c) => c.id === companyId);
  if (!company) return [];
  // include reports filed against any alias id in this company's group
  const aliasIds = new Set([company.id, ...(company.aliasOf || []), ...(company.aliasIds || [])]);
  return getReports().filter((r) => aliasIds.has(r.companyId));
}

function getUsers() {
  if (!fs.existsSync(USERS_FILE)) return [];
  return readJson(USERS_FILE);
}

function saveUsers(users) {
  writeJson(USERS_FILE, users);
}

module.exports = {
  getCompanies,
  saveCompanies,
  getReports,
  saveReports,
  getReportsForCompany,
  getUsers,
  saveUsers,
};
