const express = require("express");
const cors = require("cors");
const path = require("path");

const companiesRouter = require("./routes/companies");
const reportsRouter = require("./routes/reports");
const evidenceRouter = require("./routes/evidence");
const analysisRouter = require("./routes/analysis");
const settingsRouter = require("./routes/settings");
const authRouter = require("./routes/auth");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
// raised from the default 100kb so a captured avatar photo (data URL)
// fits in the request body
app.use(express.json({ limit: "3mb" }));

app.use("/api/auth", authRouter);
app.use("/api/companies", companiesRouter);
app.use("/api/reports", reportsRouter);
app.use("/api/evidence", evidenceRouter);
app.use("/api/analysis", analysisRouter);
app.use("/api/settings", settingsRouter);

// serve the frontend - login is the entry point; static after it serves
// everything else (index.html, css, js) as before
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "public", "login.html")));
app.use(express.static(path.join(__dirname, "public")));

app.listen(PORT, () => {
  console.log(`TrustCheck running at http://localhost:${PORT}`);
});
